<template>
  <div class="dashboard-container">
    <div class="app-container">
      <h2>社保</h2>
    </div>
  </div>
</template>

<script>
export default {}
</script>

<style></style>
